-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.5.5-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win32
-- HeidiSQL Versão:              11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Copiando estrutura do banco de dados para jhonny
CREATE DATABASE IF NOT EXISTS `jhonny` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jhonny`;

-- Copiando estrutura para tabela jhonny.caixa
CREATE TABLE IF NOT EXISTS `caixa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) DEFAULT NULL,
  `descricao` varchar(75) DEFAULT NULL,
  `tipo_contas` varchar(30) DEFAULT NULL,
  `tipo_pagamento` varchar(30) DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `saldo` decimal(10,2) DEFAULT NULL,
  `troco` decimal(10,2) DEFAULT NULL,
  `prev_fechamento` date DEFAULT NULL,
  `open_date` date DEFAULT NULL,
  `close_date` date DEFAULT NULL,
  `status_usuario` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='caixa';

-- Copiando dados para a tabela jhonny.caixa: ~5 rows (aproximadamente)
/*!40000 ALTER TABLE `caixa` DISABLE KEYS */;
INSERT INTO `caixa` (`id`, `nome`, `descricao`, `tipo_contas`, `tipo_pagamento`, `valor`, `data`, `saldo`, `troco`, `prev_fechamento`, `open_date`, `close_date`, `status_usuario`) VALUES
	(1, 'Mauro Mora', 'FIBRA/INTERNET280MB', 'FECHAM. DIÁRIO', 'DÉBITO', 240.00, '2020-09-18', 240.00, 240.00, '2020-09-18', '2020-09-09', '2020-09-17', 'ABERTO'),
	(2, 'Michael Heming', 'FIBRA/INTERNET120MB', 'FECHAM. DIÁRIO', 'CRÉDITO', 100.00, '2020-09-18', 100.00, 100.00, '2020-09-18', '2020-09-10', '2020-09-19', 'ABERTO'),
	(3, 'Gabriel Marcato', 'FIBRA/INTERNET500MB', 'FECHAM. MENSAL', 'DÉBITO', 380.00, '2020-09-18', 380.00, 380.00, '2020-09-18', '2020-09-02', '2020-09-11', 'FECHADO'),
	(4, 'John Berg', 'FIBRA/INTERNET120MB', 'FECHAM. MENSAL', 'CRÉDITO', 80.00, '2020-09-18', 80.00, 80.00, '2020-09-18', '2020-09-02', '2020-09-11', 'FECHADO'),
	(6, 'Joemil AD BRAX', 'TV - FIBRA/INTERNET 240MB', 'FECHAM. DIÁRIO', 'CRÉDITO', 186.00, '2020-09-24', 186.00, 186.00, '2020-09-24', '2020-08-18', '2020-09-18', 'ABERTO');
/*!40000 ALTER TABLE `caixa` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.caixas_aberturas
CREATE TABLE IF NOT EXISTS `caixas_aberturas` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `data` int(11) unsigned DEFAULT NULL,
  `situacao` char(1) DEFAULT 'A',
  `troco` decimal(10,2) DEFAULT 0.00,
  `entradas` decimal(10,2) DEFAULT 0.00,
  `saidas` decimal(10,2) DEFAULT 0.00,
  `saldo` decimal(10,2) DEFAULT 0.00,
  `data_hora_fechamento` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.caixas_aberturas: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `caixas_aberturas` DISABLE KEYS */;
/*!40000 ALTER TABLE `caixas_aberturas` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.caixas_movimentos
CREATE TABLE IF NOT EXISTS `caixas_movimentos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_caixas` int(11) unsigned NOT NULL DEFAULT 0,
  `id_caixas_aberturas` int(11) unsigned NOT NULL DEFAULT 0,
  `id_plano_contas` int(11) unsigned NOT NULL DEFAULT 0,
  `data` date DEFAULT NULL,
  `historico` varchar(60) DEFAULT NULL,
  `valor` decimal(10,2) NOT NULL DEFAULT 0.00,
  `entrada` decimal(10,2) NOT NULL DEFAULT 0.00,
  `saida` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tipo` char(1) DEFAULT 'E',
  `data_hora_lancam` datetime DEFAULT NULL,
  `situacao` char(50) DEFAULT 'A',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `id_caixas_aberturas` (`id_caixas_aberturas`),
  KEY `id_caixas` (`id_caixas`),
  KEY `id_plano_contas` (`id_plano_contas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.caixas_movimentos: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `caixas_movimentos` DISABLE KEYS */;
/*!40000 ALTER TABLE `caixas_movimentos` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.cidades
CREATE TABLE IF NOT EXISTS `cidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cidade` varchar(50) DEFAULT NULL,
  `uf` char(8) DEFAULT NULL,
  `cod_ibge` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.cidades: ~12 rows (aproximadamente)
/*!40000 ALTER TABLE `cidades` DISABLE KEYS */;
INSERT INTO `cidades` (`id`, `cidade`, `uf`, `cod_ibge`) VALUES
	(1, 'Sinop', 'MT', '5107909'),
	(2, 'Cuiabá', 'MT', '5103403'),
	(3, 'Sinop', 'MT', '5107909'),
	(4, 'Sinop', 'MT', '5107909'),
	(5, 'Sinop', 'MT', '5107909'),
	(6, 'Sinop', 'MT', '5107909'),
	(7, 'Cuiabá', 'MT', '5103403'),
	(8, 'Sinop', 'MT', '5107909'),
	(9, 'Sinop', 'MT', '5107909'),
	(10, 'Rondonópolis', 'MT', '5107602'),
	(11, 'Querência', 'MT', '5107065'),
	(12, 'Novo Horizonte do Norte', 'MT', '5106273'),
	(13, 'Sinop', 'MT', '5107909'),
	(14, 'Várzea Grande', 'MT', '5108402'),
	(15, 'Sinop', 'MT', '5107909');
/*!40000 ALTER TABLE `cidades` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.clientes
CREATE TABLE IF NOT EXISTS `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cidade` int(11) DEFAULT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `tipo` varchar(15) DEFAULT NULL,
  `sexo` varchar(20) DEFAULT NULL,
  `cpf` varchar(20) DEFAULT NULL,
  `rg` varchar(20) DEFAULT NULL,
  `cep` varchar(20) DEFAULT NULL,
  `endereco` varchar(50) DEFAULT NULL,
  `num_end` varchar(20) DEFAULT NULL,
  `bairro` varchar(50) DEFAULT NULL,
  `complemento` varchar(20) DEFAULT NULL,
  `insc_estadual` varchar(20) DEFAULT NULL,
  `celular` varchar(20) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `data_cadastro` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_cidade` (`id_cidade`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.clientes: ~10 rows (aproximadamente)
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` (`id`, `id_cidade`, `nome`, `tipo`, `sexo`, `cpf`, `rg`, `cep`, `endereco`, `num_end`, `bairro`, `complemento`, `insc_estadual`, `celular`, `telefone`, `email`, `data_nascimento`, `data_cadastro`) VALUES
	(1, NULL, 'John Berg', 'FÍSICA', 'MASCULINO', '062.037.061-08', '  .   .   - ', '78555-012', 'Rua dos Angicos', '1006', 'Jardim Imperial', NULL, '   .   .   .   ', '(  )     -    ', '(  )     -    ', 'JohnBerg@jb.com', '1899-12-30', '2020-11-30'),
	(2, NULL, 'Yago Murilo Diogo Castro', 'FÍSICA', 'MASCULINO', '226.463.141-40', '42.864.951-8', '78550-702', 'Avenida Abel Dal Bosco', '991', 'Residencial Cidade Jardim', NULL, '   .   .   .   ', '(  )     -    ', '(  )     -    ', 'yagomurilodiogocastro@zootecnista.com.br', '1990-07-20', '2020-11-30'),
	(3, NULL, 'Rayssa Stefany Emily da Conceição', 'FÍSICA', 'FEMENINO', '963.081.901-52', '29.827.447-4', '78075-765', 'Rua Três Mil e Quinhentos', '695', 'Jardim Imperial', NULL, '   .   .   .   ', '(  )     -    ', '(  )     -    ', 'rayssastefanyemilydaconceicao@bakerhughes.com', '1990-03-16', '2020-11-30'),
	(4, NULL, 'Isadora Sueli da Rosa', 'FÍSICA', 'FEMENINO', '200.654.981-27', '22.379.184-2', '78555-120', 'Rua Cabo Manoel Augustinho Nascimento', '902', 'Residencial Vitória Régia', NULL, '   .   .   .   ', '(  )     -    ', '(  )     -    ', 'isadorasuelidarosa_@capua.com.br', '1990-01-15', '2020-11-30'),
	(5, NULL, 'Tatiana Assmann Meinerz Eireli - EPP', 'JURÍDICA', 'FEMENINO', '05.825.100/0001-70', '  .   .   - ', '78556-106', 'Rua das Cerejeiras', '1987', 'Jardim Paraíso', NULL, '   .   .   .   ', '(  )     -    ', '(  )     -    ', 'ESCRINORTE@ESCRINORTE.COM.BR', '1899-12-30', '2020-11-30'),
	(6, NULL, 'Noah Joaquim da Cruz', 'FÍSICA', 'MASCULINO', '697.711.521-14', '19.741.844-2', '78643-970', 'Avenida Cuiabá 35 Setor C', '934', 'Centro', NULL, '   .   .   .   ', '(  )     -    ', '(  )     -    ', 'noahjoaquimdacruz-80@webin.com.br', '1985-11-11', '2020-11-30'),
	(7, NULL, 'Débora Andrea Gonçalves', 'FÍSICA', 'FEMENINO', '901.200.421-77', '10.823.436-8', '78570-970', 'Avenida Mestre Falcão 343', '755', 'Centro', NULL, '   .   .   .   ', '(  )     -    ', '(  )     -    ', 'deboraandreagoncalves@sha.com.br', '1985-11-25', '2020-11-30'),
	(8, NULL, 'Catarina Sophia Débora Carvalho', 'FÍSICA', 'MASCULINO', '355.670.911-25', '27.022.191-8', '78556-532', 'Rua Gal Costa', '559', 'Residencial Aquarela Brasil', NULL, '   .   .   .   ', '(  )     -    ', '(  )     -    ', 'catarinasophiadeboracarvalho-88@alesalvatori.com', '1987-12-20', '2021-01-08'),
	(9, NULL, 'Hugo Thales Moreira', 'FÍSICA', 'MASCULINO', '150.124.571-61', '42.927.191-8', '78149-366', 'Rua Tapiriri', '671', 'Novo Mundo', NULL, '   .   .   .   ', '(  )     -    ', '(  )     -    ', 'hugothalesmoreira@mixfmmanaus.com.br', '1987-04-20', '2021-01-05');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.contas_receber
CREATE TABLE IF NOT EXISTS `contas_receber` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) DEFAULT NULL,
  `id_documento` int(11) DEFAULT NULL,
  `id_pedidos` int(11) DEFAULT NULL,
  `descricao` varchar(110) DEFAULT NULL,
  `data_documento` date DEFAULT NULL,
  `data_vencimento` date DEFAULT NULL,
  `desconto` decimal(18,2) NOT NULL DEFAULT 0.00,
  `pago` char(1) DEFAULT 'N',
  `valor` decimal(18,2) NOT NULL DEFAULT 0.00,
  `num_parcela` varchar(10) DEFAULT NULL,
  `data_cadastro` date DEFAULT NULL,
  `obs_quitacao` varchar(20) DEFAULT NULL,
  `vencimento` date DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ndx_cliente` (`id_cliente`) USING BTREE,
  KEY `ndx_documento` (`id_documento`) USING BTREE,
  KEY `ndx_data_vencimento` (`data_vencimento`),
  KEY `id_pedidos_iten` (`id_pedidos`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.contas_receber: ~16 rows (aproximadamente)
/*!40000 ALTER TABLE `contas_receber` DISABLE KEYS */;
INSERT INTO `contas_receber` (`id`, `id_cliente`, `id_documento`, `id_pedidos`, `descricao`, `data_documento`, `data_vencimento`, `desconto`, `pago`, `valor`, `num_parcela`, `data_cadastro`, `obs_quitacao`, `vencimento`) VALUES
	(1, 3, 5, NULL, 'FIBRA/INTERNET - 320MB', '2020-11-16', '2020-12-15', 0.00, 'S', 240.00, NULL, '2020-12-16', NULL, NULL),
	(2, 4, 5, NULL, 'FIBRA/INTERNET - 320MB + TV/CANAL - PREMIUM', '2020-12-15', '2021-01-15', 0.00, 'N', 280.00, NULL, '2020-12-16', NULL, NULL),
	(3, 9, 5, NULL, 'FIBRA/INTERNET - 240MB + TV/CANAL - PREMIUM', '2020-12-16', '2021-01-16', 0.00, 'N', 200.00, NULL, '2020-12-16', NULL, NULL),
	(4, 8, 1, NULL, 'FIBRA/INTERNET - 240MB', '2020-11-14', '2020-12-14', 0.00, 'N', 160.00, NULL, '2020-12-16', NULL, NULL),
	(5, 6, 5, NULL, 'TV/CANAL - PREMIUM/FULL HD', '2020-11-10', '2020-12-10', 0.00, 'N', 120.00, NULL, '2020-12-16', NULL, NULL),
	(6, 2, 6, NULL, 'TV/CANAL - PREMIUM/FULL HD', '2020-11-03', '2020-12-03', 0.00, 'S', 120.00, NULL, '2020-12-16', NULL, NULL),
	(7, NULL, NULL, NULL, NULL, '1899-12-30', NULL, 0.00, 'N', 750.21, '01/05', NULL, NULL, '2020-12-15'),
	(8, NULL, NULL, NULL, NULL, '1899-12-30', NULL, 0.00, 'N', 750.21, '02/05', NULL, NULL, '2021-01-15'),
	(9, NULL, NULL, NULL, NULL, '1899-12-30', NULL, 0.00, 'N', 750.21, '03/05', NULL, NULL, '2021-02-15'),
	(10, NULL, NULL, NULL, NULL, '1899-12-30', NULL, 0.00, 'N', 750.21, '04/05', NULL, NULL, '2021-03-15'),
	(11, NULL, NULL, NULL, NULL, '1899-12-30', NULL, 0.00, 'N', 750.21, '05/05', NULL, NULL, '2021-04-15'),
	(12, 1, 5, 1, 'Pedido de parcelas em 05/05x / da venda: John Berg', '2020-12-15', '2020-12-15', 0.00, 'N', 3751.09, '05/05', NULL, NULL, NULL),
	(39, NULL, NULL, NULL, NULL, '1899-12-30', NULL, 0.00, 'N', 2105.17, '01/03', NULL, NULL, '2020-12-16'),
	(40, NULL, NULL, NULL, NULL, '1899-12-30', NULL, 0.00, 'N', 2105.17, '02/03', NULL, NULL, '2021-01-16'),
	(41, NULL, NULL, NULL, NULL, '1899-12-30', NULL, 0.00, 'N', 2105.17, '03/03', NULL, NULL, '2021-02-16'),
	(42, 5, 5, 3, 'Pedido de parcelas em  03/03x / da venda: Tatiana Assmann Meinerz Eireli - EPP', '2020-12-16', '2020-12-16', 0.00, 'N', 6315.53, '03/03', NULL, NULL, NULL);
/*!40000 ALTER TABLE `contas_receber` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.contas_receber_pagtos
CREATE TABLE IF NOT EXISTS `contas_receber_pagtos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_contas_receber` int(11) unsigned DEFAULT 0,
  `data_pagamento` date DEFAULT NULL,
  `dias_atraso` int(11) NOT NULL DEFAULT 0,
  `juros` decimal(18,2) NOT NULL DEFAULT 0.00,
  `desconto` decimal(18,2) NOT NULL DEFAULT 0.00,
  `total_pagar` decimal(10,2) NOT NULL DEFAULT 0.00,
  `valor_pago` decimal(18,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `id_contas_receber` (`id_contas_receber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.contas_receber_pagtos: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `contas_receber_pagtos` DISABLE KEYS */;
/*!40000 ALTER TABLE `contas_receber_pagtos` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.formas_pagtos
CREATE TABLE IF NOT EXISTS `formas_pagtos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `forma_pagto` varchar(50) DEFAULT NULL,
  `entrada` char(1) DEFAULT 'N',
  `parcelas` int(2) DEFAULT NULL,
  `primeiro_mes` int(2) DEFAULT NULL,
  `intervalo` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.formas_pagtos: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `formas_pagtos` DISABLE KEYS */;
/*!40000 ALTER TABLE `formas_pagtos` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.parcelas_vendas
CREATE TABLE IF NOT EXISTS `parcelas_vendas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_parcelas` int(11) DEFAULT NULL,
  `vencimento` date DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `tipo_pagtos` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_parcelas` (`id_parcelas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.parcelas_vendas: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `parcelas_vendas` DISABLE KEYS */;
/*!40000 ALTER TABLE `parcelas_vendas` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.pedidos
CREATE TABLE IF NOT EXISTS `pedidos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_vendedores` int(11) DEFAULT NULL,
  `id_clientes` int(11) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `total_produtos` decimal(10,2) DEFAULT NULL,
  `desconto` decimal(10,3) DEFAULT NULL,
  `desconto_valor` decimal(10,2) DEFAULT NULL,
  `total_pagar` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_vendedores` (`id_vendedores`),
  KEY `id_clientes` (`id_clientes`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.pedidos: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
INSERT INTO `pedidos` (`id`, `id_vendedores`, `id_clientes`, `data`, `total_produtos`, `desconto`, `desconto_valor`, `total_pagar`) VALUES
	(1, 2, 1, '2020-12-15', 3751.09, 0.000, 0.00, 3751.09),
	(3, 3, 5, '2020-12-16', 7430.04, 15.000, 1114.51, 6315.53),
	(4, 2, 7, '2020-12-15', 5909.09, 10.000, 590.91, 5318.18);
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.pedidos_itens
CREATE TABLE IF NOT EXISTS `pedidos_itens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pedidos` int(11) DEFAULT NULL,
  `id_produtos` int(11) DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `qtde` decimal(10,3) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pedidos` (`id_pedidos`),
  KEY `id_produtos` (`id_produtos`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.pedidos_itens: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `pedidos_itens` DISABLE KEYS */;
INSERT INTO `pedidos_itens` (`id`, `id_pedidos`, `id_produtos`, `valor`, `qtde`, `total`) VALUES
	(1, 1, 8, 3376.25, 1.000, 3376.25),
	(2, 1, 13, 374.84, 1.000, 374.84),
	(4, 3, 8, 3376.25, 2.000, 6752.50),
	(5, 3, 13, 374.84, 1.000, 374.84),
	(6, 3, 14, 151.35, 2.000, 302.70),
	(7, 4, 27, 2158.00, 1.000, 2158.00),
	(8, 4, 8, 3376.25, 1.000, 3376.25),
	(9, 4, 13, 374.84, 1.000, 374.84);
/*!40000 ALTER TABLE `pedidos_itens` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.plano_contas
CREATE TABLE IF NOT EXISTS `plano_contas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plano_contas` varchar(60) DEFAULT NULL,
  `estrutura` varchar(30) DEFAULT NULL,
  `situacao` char(1) NOT NULL DEFAULT 'A',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.plano_contas: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `plano_contas` DISABLE KEYS */;
/*!40000 ALTER TABLE `plano_contas` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.produtos
CREATE TABLE IF NOT EXISTS `produtos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_produto_grupo` int(11) DEFAULT NULL,
  `id_unid_medidas` int(11) DEFAULT NULL,
  `produto` varchar(80) DEFAULT NULL,
  `preco_compra` decimal(10,2) DEFAULT NULL,
  `preco_venda` decimal(10,2) DEFAULT NULL,
  `margem_lucro` decimal(10,3) DEFAULT NULL,
  `cod_barras` varchar(30) DEFAULT NULL,
  `cod_referencias` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_unid_medidas` (`id_unid_medidas`),
  KEY `id_produto_grupo` (`id_produto_grupo`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.produtos: ~21 rows (aproximadamente)
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` (`id`, `id_produto_grupo`, `id_unid_medidas`, `produto`, `preco_compra`, `preco_venda`, `margem_lucro`, `cod_barras`, `cod_referencias`) VALUES
	(1, 2, 9, 'ADAPTADOR OPTICO SC/UPC SEM ABA', 100.00, 123.00, 123.000, '111111111', '111111111111'),
	(2, 3, 8, 'ANTENA PAINEL SETORIAL 5.8 ', 123.00, 200.00, 77.000, 'AAAA', 'BBBB'),
	(3, 6, 9, 'CABO FIBRA ÓTICA ', 8.00, 12.00, 4.000, 'ASD', 'ASD'),
	(4, 6, 9, 'CABO OPTICO CFOAC-BLI-A/B-CM-01-AR-LSZH PR - BOBINA', 0.65, 0.85, 0.200, 'A12H23H1G', '1231J1N1NS'),
	(5, 6, 9, 'CABO OPTICO CFOA-SM-AS80', 128.00, 129.27, 1.270, 'AA23ST1TDS', '122AAEDW11'),
	(6, 11, 8, 'CAIXA DE ATENDIMENTO ÓPTICA', 94.50, 109.50, 15.000, 'AA43134FF2', '123SS13412'),
	(7, 8, 8, 'CAIXA DE EMENDA FIBRA ÓPTICA FIBRACEM 24 F SVM (7A12)', 190.00, 214.52, 24.520, 'GGH12341', '123FGG144'),
	(8, 1, 8, 'COMPUTADORES', 3200.50, 3376.25, 175.750, 'ASD3311DSA', '123ZA123S'),
	(9, 13, 8, 'DIO DISTRIBUIDOR INTERNO ÓPTICO', 400.00, 425.00, 25.000, 'KJKFÇPLÇ12', 'LLKK1I2311'),
	(10, 9, 9, 'DROP COMPACTO FIG.8 LOW FRICTION', 1200.00, 1500.00, 300.000, 'KK23K8K8K', 'K3888I122'),
	(11, 17, 8, 'ESCADA DUPLA ESTICAVEL 13 DEGRAUS', 600.00, 690.00, 90.000, 'KLKHLF3543', '345FF3533'),
	(12, 9, 9, 'FITA M-TAPE M-231 12MM PRETO SOBRE BRANCO ROLO 8M', 59.00, 64.90, 5.900, 'JJ34599JA', 'QQ12EW1W'),
	(13, 17, 8, 'FONTE NOBREAK', 357.00, 374.84, 17.840, 'CCE4RLK22', '44K2L2DDSA'),
	(14, 17, 8, 'GABINETE 1 PARA PAC-EPON', 96.60, 151.35, 54.750, 'HH567J4GGF', '5456GG344'),
	(15, 9, 8, 'OLT HUAWEI', 199.90, 460.40, 260.500, 'GG644K54M', '55G2B3DD3'),
	(16, 8, 8, 'ONU GPON AN5506-02B', 59.00, 276.00, 217.000, 'FF234D144', '123DD213D'),
	(17, 9, 8, 'ONU GPON HUAWEI', 161.40, 180.72, 19.320, 'KK45723KKD', '23SSS312'),
	(18, 7, 7, 'P H2I BOB CABO', 522.32, 580.00, 57.680, 'FF78J224', '44GTFR77'),
	(20, 18, 8, 'SPLITTER 1X2 DESBALANCEADO 20/80 - FIBRA OPTICA COM PRISMA DIVISOR DE FOTONS 1X2', 40.91, 60.91, 20.000, '', ''),
	(21, 18, 8, 'SPLITTER 1X2 DESBALANCEADO 5/95 - FIBRA OPTICA COM PRISMA DIVISOR DE FOTONS 1X2 ', 40.91, 65.91, 25.000, '', ''),
	(22, 18, 8, 'SPLITTER 1X2 DESBALANCEADO 90/10 - FIBRA OPTICA COM PRISMA DIVISOR DE FOTONS 1X2', 40.91, 85.91, 45.000, '', ''),
	(27, 20, 12, 'MONITOR / LED - 1080P/ 60HZ', 1863.00, 2158.00, 295.000, '', '');
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.produtos_grupo
CREATE TABLE IF NOT EXISTS `produtos_grupo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `produtos_grupo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.produtos_grupo: ~17 rows (aproximadamente)
/*!40000 ALTER TABLE `produtos_grupo` DISABLE KEYS */;
INSERT INTO `produtos_grupo` (`id`, `produtos_grupo`) VALUES
	(1, 'TOPSAPP'),
	(2, 'GRUPO CIDADE SINOP'),
	(3, 'GRUPO CIDADE PEIXOTO'),
	(4, 'GRUPO CIDADE SORRISO'),
	(5, 'CONECTORES'),
	(6, 'CABOS'),
	(7, 'ANTENAS'),
	(8, 'FTTX'),
	(9, 'FTTH'),
	(10, 'GRUPO SUPORTE'),
	(11, 'TOPMAPS'),
	(12, 'GRUPO CIDADE CUIABA'),
	(13, 'GRUPO TOPMAPS'),
	(14, 'GRUPO TOPSAPP'),
	(15, 'GRUPO ADBRAX'),
	(17, 'OUTROS'),
	(18, 'INFRAESTRUTURA'),
	(20, 'SUPORTE TÉCNICO TOPSAPP');
/*!40000 ALTER TABLE `produtos_grupo` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.tipos_documentos
CREATE TABLE IF NOT EXISTS `tipos_documentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `documento` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.tipos_documentos: ~6 rows (aproximadamente)
/*!40000 ALTER TABLE `tipos_documentos` DISABLE KEYS */;
INSERT INTO `tipos_documentos` (`id`, `documento`) VALUES
	(1, 'DINHEIRO'),
	(2, 'BOLETO'),
	(3, 'CARNÊ'),
	(4, 'DUPLICATA'),
	(5, 'CARTÃO DE CRÉDITO'),
	(6, 'CARTÃO DE DÉBITO'),
	(7, 'CHEQUE');
/*!40000 ALTER TABLE `tipos_documentos` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.unid_medidas
CREATE TABLE IF NOT EXISTS `unid_medidas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unid_medida` varchar(30) DEFAULT NULL,
  `abrev` char(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.unid_medidas: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `unid_medidas` DISABLE KEYS */;
INSERT INTO `unid_medidas` (`id`, `unid_medida`, `abrev`) VALUES
	(7, 'CENTIMENTROS', 'CM'),
	(8, 'UNIDADE', 'UN'),
	(9, 'METROS', 'M'),
	(10, 'TONELADAS', 'TON'),
	(11, 'KILO', 'K'),
	(12, 'PECAS', 'PC');
/*!40000 ALTER TABLE `unid_medidas` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.usuario
CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) DEFAULT NULL,
  `cpf` varchar(20) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `data_cadastro` date DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.usuario: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;

-- Copiando estrutura para tabela jhonny.vendedores
CREATE TABLE IF NOT EXISTS `vendedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vendedor` varchar(60) DEFAULT NULL,
  `comissao` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela jhonny.vendedores: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `vendedores` DISABLE KEYS */;
INSERT INTO `vendedores` (`id`, `vendedor`, `comissao`) VALUES
	(1, 'Michael Hemming', 0.00),
	(2, 'Mauro Moura', 0.00),
	(3, 'Gabriel Neves', 0.00),
	(4, 'Gabriel da Silva', 0.00);
/*!40000 ALTER TABLE `vendedores` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
